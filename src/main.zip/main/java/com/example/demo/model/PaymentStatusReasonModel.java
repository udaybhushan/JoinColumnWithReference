package com.example.demo.model;

public class PaymentStatusReasonModel {
	
	private String reason;

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	
}
